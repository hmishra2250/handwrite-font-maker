# Character map for My Handwrite

| Character | Unicode | Glyph name | Advance width | Scale | Spacing (em) |
| --- | --- | --- | ---: | ---: | ---: |
| A | `U+0041` | `A` | 860 | 1.2 | 0.1 |
| B | `U+0042` | `B` | 602 | 1 | 0 |
| C | `U+0043` | `C` | 629 | 1 | 0 |
| D | `U+0044` | `D` | 656 | 1 | 0 |
| E | `U+0045` | `E` | 618 | 1 | 0 |
