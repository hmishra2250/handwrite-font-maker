# My Handwrite

Package for `MyHandwrite-Regular` / `Regular`.

## Files

- `fonts/MyHandwrite-Regular.ttf`
- `fonts/MyHandwrite-Regular.otf`
- `CHARACTER_MAP.md`

## Installation

Use your operating system or target application's normal font installation/import flow for TTF or OTF files.
Exact steps vary by platform and application; this package does not claim automatic OS install or Office compatibility testing.

## Rights

Rights to the generated font output depend on your rights to the input glyph images.
The app license does not automatically license your output or third-party source material.

## Character map

See `CHARACTER_MAP.md` for the typed character assigned to each generated glyph.
